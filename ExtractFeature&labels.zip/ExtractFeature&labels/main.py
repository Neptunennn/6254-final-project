from model import VGG16
from utils import Data
import h5py
import pickle


root_path = '/Users/guxiaofeng/Desktop/Gatech/ECE6254/Project/ece6254_data'
vgg16_weights_path = '/Users/guxiaofeng/Desktop/Gatech/ECE6254/Project/ece6254_data/vgg16_weights.h5'
our_weights_path = '/Users/guxiaofeng/Desktop/Gatech/ECE6254/Project/ece6254_data/weights.h5'

data = Data(root_path, load_size=2)



model = VGG16(our_weights_path, vgg16_weights_path)


Y,X =  model.predict(data, batch_size=32, nb_epoch=1)



output1 = open('feature.pkl','wb')
output2 = open('label.pkl','wb')
pickle.dump(X,output1,-1)
pickle.dump(Y,output2,-1)
output1.close()
output2.close()





